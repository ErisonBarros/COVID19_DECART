# DATASUS: Sistema de Informações Hospitalares.

### Este arquivo contém as principais funções necessárias para
### montar as bases de dados do SIH do DataSUS.
### A idéia é construir um catálogo com a função catalog_sihsus(),
### filtrar (ou não) os dados desejados, depois montar as bases de dados
### no disco usando a função build_sihsus().

### funções auxiliares
link_scrape <- function( x ) {
  library(RCurl , quietly = TRUE )
  custom_recodes <- c( "í" = "%ED" , "á" = "%E1" , "ã" = "%E3" , " " = "%20" )
  custom_recodes <- NULL
  if ( !is.null( x ) ){
    this_text <- getURL( x , .encoding = 'ISO-8859-1' , .opts = list(timeout = 10 , dirlistonly = TRUE , ftplistonly = TRUE , ftp.use.epsv = FALSE ) )
    this_text <- unlist( strsplit( this_text , "\n" ) )
    this_text <- curlPercentEncode( this_text , codes = custom_recodes )
    paste0( x , this_text )
  } else { 
    NULL 
  }
}

getlisting <- function( these_urls ) {
  
  library(future.apply)
  plan(multiprocess)
  
  these_urls <- ifelse( grepl( "\\/$" , these_urls ) , these_urls , paste0( these_urls , "/" ) )
  res <- future_lapply( these_urls , link_scrape )
  res <- unlist( res )
  res <- res[ !grepl( "SISPRENATAL\\/201201_\\/Doc$", res ) ] # folder not loading in server
  is.file <- grepl( "\\." , basename( res ) , ignore.case = TRUE )
  res[ !is.file ] <- ifelse( grepl( "\\/$" , res[ !is.file ] ) , res[ !is.file ] , paste0( res[ !is.file ] , "/" ) )
  list( dirs = if ( any(!is.file) ) { res[ !is.file ] } else { NULL } , 
        files = if ( any(is.file) ) { res[ is.file ] } else { NULL } )
}

recursive_ftp_scrape <- function( main_url , max.iter = Inf ) {
  
  final_files <- NULL
  
  directories <- main_url
  
  i=0
  while ( length(directories) > 0 ) {
    i=i+1
    if ( i > max.iter ) { break() }
    listing <- getlisting(directories)
    directories <- listing[[1]]
    files <- listing[[2]]
    final_files <- c(final_files, files )
    if ( length( directories) > 0 ) cat( length(directories) , "new directories found.\n" ) else cat( "done!\n" )
  }
  
  return( final_files )
  
}

### cria catálogo de dados
catalog_sihsus <- function( output_dir , drop.prelim = TRUE ){
  
  # define pastas-raízes
  sus_htmls <- "ftp://ftp.datasus.gov.br/dissemin/publicos/SIHSUS/200801_/Dados/"
  # sus_htmls <- paste0( "ftp://ftp.datasus.gov.br/dissemin/publicos/" , c( "SIM" , "SINASC" ) , "/" )
  
  # percorre diretórios
  all_links <- recursive_ftp_scrape( sus_htmls )
  
  # cria lista inicial
  these_links <- all_links
  
  # mantém apenas arquivos .dbc
  these_links <- these_links[ grepl( "\\.dbc$" , these_links , ignore.case = TRUE ) ]
  
  # filtra apenas arquivos com prefixo SP ou RD
  these_links <- these_links[ grepl( "^(SP|RD)" , basename( these_links ) , ignore.case = TRUE ) ]
  
  # cria catálogo de links
  catalog <-
    data.frame(
      full_url = these_links ,
      type = substr( basename( these_links ) , 1 , 2 ) ,
      state = substr( basename( these_links ) , 3 , 4 ) ,
      year = paste0( "20" , substr( basename( these_links ) , 5 , 6 ) ) ,
      month = substr( basename( these_links ) , 7 , 8 ) ,
      stringsAsFactors = FALSE
    )
  
  # redefine tipo
  catalog[ catalog$type == "RD" , "type" ] <- "Dados Consolidados"
  catalog[ catalog$type == "SP" , "type" ] <- "Dados Detalhados"
  
  # define nome do arquivo destino
  catalog$output_filename <- file.path( output_dir , catalog$type , gsub( "\\.(dbc|dbf)" , ".fst" , tolower( basename( these_links ) ) ) )
  
  # reordena catálogo
  catalog <- catalog[ order( catalog$type , catalog$state , catalog$year ) , ]
  
  # retorna catálogo
  catalog
  
}

# cria datavault
datavault_sihsus <- function( catalog , datavault_dir , skipExist = TRUE ) {
  
  # carrega libraries
  library(future.apply)
  
  # define processamento paralelo
  plan(multiprocess)
  
  # define pastas do datavault
  catalog[ , "datavault_file" ] <- gsub( "ftp://ftp.datasus.gov.br/dissemin/publicos/SIHSUS" , datavault_dir , catalog$full_url , fixed = TRUE )
  catalog[ , "datavault_file" ] <- gsub( "//" , "/" , catalog[ , "datavault_file" ] , fixed = TRUE )
  
  # procura arquivos existentes
  existing_files <- file.exists( catalog[ , "datavault_file" ] )
  
  # baixa arquivos
  lapply( seq_along( catalog$full_url ) , function( this_entry ) {
    
    # cria arquivo temporário
    tf <- tempfile()
    
    # pula arquivos existentes
    if ( file.exists( catalog[ this_entry , "datavault_file" ] ) ){ cat( "file" , this_entry , "out of" , nrow( catalog ) , "downloaded to" , datavault_dir , "\r") ; return( NULL ) }
    
    # cria pasta destino
    dir.create( dirname( catalog[ this_entry , "datavault_file" ] ) , recursive = TRUE , showWarnings = FALSE )
    
    # baixa arquivo
    download.file( catalog[ this_entry , "full_url" ], tf , mode = "wb" , quiet = TRUE )
    
    # copia para pastaa final
    file.copy( tf , catalog[ this_entry , "datavault_file" ] )
    
    # remove temporário
    file.remove( tf )
    
    # acompanhamento de processo
    cat( "file" , this_entry , "out of" , nrow( catalog ) , "downloaded to" , datavault_dir , "\r")
    
  } )
  
  # mostra mensagem
  cat( "\ndatasus datavault was built at" , datavault_dir , "\n" )
  
  # returna catálogo
  catalog
  
}


### monta bases de dados
build_sihsus <- function( catalog , skipExist = TRUE ) {
  
  # carrega pacotes
  library(data.table)
  library(read.dbc)
  library(fst)
  library(stringr)
  
  # cria arquivo temporário
  tf <- tempfile()
  
  # "circula" pelas entradas do catálogo
  for ( i in seq_len( nrow( catalog ) ) ){
    
    # pula arquivo existente
    if (skipExist & file.exists( catalog[ i , "output_filename"] ) ) {
      catalog[ i , 'case_count' ] <- fst.metadata( catalog[ i , "output_filename"] )$nrOfRows
      cat( paste0( catalog[ i , 'output_filename' ] , " already exists. Skippping.\r" ) )
      next()
    } 
    
    # baixa arquivo de dados
    if ( is.null( catalog[ i , "datavault_file" ] ) ) {
      download.file( catalog[ i , "full_url" ] , tf , quiet = TRUE , mode = "wb" )
    } else if ( is.na( catalog[ i , "datavault_file" ] ) ) {
      download.file( catalog[ i , "full_url" ] , tf , quiet = TRUE , mode = "wb" ) 
    } else {
      file.copy( catalog[ i , "datavault_file" ] , tf , overwrite = TRUE )
    }
    
    # lê arquivo .dbc
    x <- read.dbc( tf , as.is = TRUE )
    
    # converte para data.table
    x <- data.table( x )
    
    # nomes das colunas em minúsculo
    names( x ) <- tolower( names( x ) )
    
    # remove espaços desnecessários nos nomes
    names( x ) <- trimws( names( x ) , which = "both" )
    
    # adiciona underscores depois de nomes reservados do monetdb
    for ( j in names( x )[ toupper( names( x ) ) %in% getFromNamespace( "reserved_monetdb_keywords" , "MonetDBLite" ) ] ) names( x )[ names( x ) == j ] <- paste0( j , "_" )
    
    # descobre quais colunas podem ser numéricas
    for( this_col in names( x )[ !grepl( "^(cod|causabas|linha|ocup|dt|numero|idade|sexo)" , names( x ) ) ] ){
      
      # se pode ser convertida sem alerta, converte para númerico
      this_result <- tryCatch( as.numeric( x[[this_col]] ) , warning = function(c) NULL , error = function(c) NULL )
      
      # converte para numérico
      if( !is.null( this_result ) ) x[ , (this_col) := lapply( .SD , as.numeric ) , .SDcols = this_col ]
      
    }
    
    # salva contagem de casos
    catalog[ i , 'case_count' ] <- nrow( x )
    
    # salva arquivo no disco
    dir.create( dirname( catalog[ i , 'output_filename' ] ) , recursive = TRUE , showWarnings = FALSE )
    if ( nrow(x) > 0 ) write_fst( x , path = catalog[ i , 'output_filename' ] , compress = 100 )
    
    # acompanhamento de processo
    cat( paste0( "datasus catalog entry " , i , " of " , nrow( catalog ) , " stored at '" , catalog[ i , 'output_filename' ] , "'\r" ) )
    
    # deleta arquivo temporário
    suppressWarnings( file.remove( tf ) )
    
  }
  
  # retorna catálogo
  catalog
  
}

